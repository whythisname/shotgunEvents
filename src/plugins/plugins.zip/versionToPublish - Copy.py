"""
Automatically calculate the Cut Duration on Shots when the Cut In or Cut Out value is changed.

Conversely, this example does not make any updates to Cut In or Cut Out values if the Cut Duration field 
is modified. You can modify that logic and/or the field names to match your specific workflow.
"""

import logging
import os.path as path

def registerCallbacks(reg):
    matchEvents = {
        'Shotgun_Version_Change': ['sg_status_list'],
    }
    
    reg.registerCallback('shotgunEventDaemon', '755d4364b9ea1b71be0ec51ccb6c219b49e91429d8cc7a4cb790763fd8dab345', versionToPublish, matchEvents, None)

    reg.logger.setLevel(logging.INFO)

def versionToPublish(sg, logger, event, args):
    """Calculate the Cut Duration as (Cut Out - Cut In) + 1 if all values are present"""

    if 'new_value' not in event['meta'] or event['meta']['new_value'] != 'apr':
        return
    


    #filters = ["sg_status_list", "is", "apr"]
    filters = [['id', 'is', event['entity']['id']]]
    fields = ['description', 'entity', 'sg_path_to_frames', 'task', 'code']
    version = sg.find_one("Version", filters, fields)
    if version is None:
        return

    filters = [['id', 'is', event['project']['id']]]
    fields = ['tank_name']
    project = sg.find_one("Project", filters, fields)
    if project is None or project['tank_name'] is None:
        return

    filters = [['id', 'is', 5]]
    fields = ['code']
    pub_type = sg.find_one("PublishedFileType", filters, fields)

    name = path.split(version['sg_path_to_frames'])
    file_path = version['sg_path_to_frames'][:version['sg_path_to_frames'].find(project['tank_name'])]
    cache_path = version['sg_path_to_frames'][version['sg_path_to_frames'].find(project['tank_name']):]
    #path.relpath(version['sg_path_to_frames'], project['tank_name'])

    data = {
    'project': event['project'],
    'code': version['code'],
    'description': version['description'],
    #'sg_status_list': 'rev',
    'entity': version['entity'],
    #'user': event['user'],
    'name': name[1],
    'path_cache': file_path,
    'path_cache_storage': {"FilesystemLocation":{'path_cache_storage':cache_path}},
    'published_file_type': pub_type,
    #'task': version['task'],
    'version': version,
    }
    publish = sg.create("PublishedFile",data)


    # lookup the cut values for this Shot
    
    #filters = [['id', 'is', event['entity']['id']]]
    #fields = ['code','sg_cut_in','sg_cut_out','sg_cut_duration']
    #shot = sg.find_one("Shot", filters, fields)
    
    
    # calculate the new duration
    # if we don't have a value for both cut in and cut out, if there is an existing
    # value in the duration field, we unset the duration
    
    #new_duration = None
    #if shot['sg_cut_in'] is not None and shot['sg_cut_out'] is not None:
    #    new_duration = (shot['sg_cut_out'] - shot['sg_cut_in']) + 1
    #elif not shot['sg_cut_duration']:
    #    return
    
    # update the Shot with the new duration
    #sg.update("Shot", shot["id"], {'sg_cut_duration':new_duration})
    logger.info("Version: %s" % (data))

